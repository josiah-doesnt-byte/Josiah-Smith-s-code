#!/bin/sh

echo "step 1"
mkdir myDir
echo

echo "step 2"
ls myDir
echo

echo "step 3"
df -i myDir
echo

echo "step 4"
touch myDir/myFile
truncate -s 2K myFile
echo

echo "step 5"
df -i myDir
echo

echo "step 6"
touch myDir/myFileEmpty
echo

echo "step 7"
df -i myDir
echo

echo "step 8"
cat myFile
echo

echo "step 9"
file myFile
echo

echo "step 10"
cd myDir
echo

echo "step 11"
pwd
echo

echo "step 12 and step 13"
if test -f myDir;
then
   echo "myDir is a regular file"
else
   echo "myDir is not a regular file"
fi

echo "step 14"
chmod 500 myFile
echo

echo "step 15"
df -i
echo

echo "step 16"
if test -r myFile;
then
   echo "myFile is readable by me"
else
   echo "myFile is not readable by me"
fi
echo

echo "step 17"
if test -w myFile;
then
   echo "myFile is writeable by me"
else
   echo "myFile is not writeable by me"
fi
echo

echo "step 18"
if test -x myFile;
then
   echo "myFile is executable by me"
else
   echo "myFile is not executable by me"
fi
echo

echo "step 19"
if test -s myFile;
then
   echo "myFile is an non-empty file"
else
   echo "myFile is an empty file"
fi
echo

echo "step 20"
if test -s myFileEmpty;
then
   echo "myFileEmpty is not an empty file"
else
   echo "myFileEmpty is an empty file"
fi
echo

echo "step 21"
df -i
echo

echo "step 22"
rm myFile
rm myFileEmpty
echo

echo "step 23"
df -i
echo

echo "step 24"
rmdir myDir
echo

echo "step 25"
df
echo
df -i
echo

echo "step 26"
cat /etc/passwd
echo

echo "step 27"
cat /etc/group
echo

echo "step 28"
sudo useradd user1
sudo useradd user2
sudo useradd user3
sudo useradd user4
echo

echo "step 29"
sudo groupadd apples
sudo groupadd oranges
echo

echo "step 30"
cat /etc/passwd
echo

echo "step 31"
cat /etc/passwd
echo

echo "step 32"
df
echo
df -i
echo

echo "step 33"
sudo usermod -a -G apples user1
sudo usermod -a -G apples user2
sudo usermod -a -G oranges user3
sudo usermod -a -G oranges user4
echo

echo "step 34"
cat /etc/passwd
echo

echo "step 35"
cat /etc/group
echo

echo "step 36"
df
echo
df -i
echo

echo "step 37"
sudo deluser user1 apples
sudo deluser user2 apples
sudo deluser user3 oranges
sudo deluser user4 oranges
sudo delgroup apples
sudo delgroup oranges
echo

echo "step 38"
cat /etc/passwd
echo

echo "step 39"
cat /etc/group
echo

echo "step 40"
df
echo
df -i
echo