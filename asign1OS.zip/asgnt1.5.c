#include <stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

#define ARRAY_SIZE 10

struct user{
int user_id;
char* user_name;
};
void populate(struct user* user, int size);

int main(void) {
  struct user arrayS[ARRAY_SIZE];
  struct user* ptr;
  ptr = &arrayS[0];
  int g = 2;
  pid_t pid = fork();
  //the child's pid
  if(pid == 0){
	while(g > 0)
	{
    printf("the child process\n");
	printf("The child's pid is: ");
	printf("%d\n", getpid());
	populate(ptr, ARRAY_SIZE);
	exit(0);
	}
  }
  //parents pid
  else if (pid > 0){
	sleep(5);  
	kill(pid, SIGKILL);
    printf("the parent process slept for 5 seconds\n");
	printf("and killed the child process");
	printf("The parent's pid is: ");
	printf("%d\n", getpid());
  }

else{
	printf("no pid");
}
  
}
void populate(struct user* users, int size)
{		
	//documented from the code we did during your office hours

	for(int i=0; i < ARRAY_SIZE; i++) {
		int id;
		char name[10];
		printf("Enter the id: ");
		scanf("%d", &id);
		printf("Enter the name: ");
		scanf("%s", &name[0]);
		users->user_id = id;
		users->user_name = name;
		users++;
	}
	
}
