#include <stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

#define ARRAY_SIZE 10

struct user{
int user_id;
char* user_name;
};
void populate(struct user* user, int size);


int main(int argc, char* argv[]) {
	
	const int segment_size = ARRAY_SIZE * 4;
	
	struct segment_id = shmget(IPC_PRIVATE, segment_size, 0666);
	
	struct user* shared_memory = (int *) shmat(segment_id, NULL, 0);
	struct user arrayS[ARRAY_SIZE];
    struct user* ptr;
    ptr = &arrayS[0];
    pid_t pid = fork();
	
	if(pid == 0) {
		populate(ptr, ARRAY_SIZE);
		*shared_memory = 1;
	}
	else {
		wait(NULL);
		printf("%d status of the child is\n", *shared_memory); //status of the child
		shmdt(shared_memory);
		shmctl(segment_id, IPC_RMID, NULL);
		printf("");
	}
	for(int i=0; i < ARRAY_SIZE; i++)
	{
		printf(arrayS[i]);
	}
	printf("Done");
} 

void populate(struct user* users, int size)
{
	for(int i=0; i < ARRAY_SIZE; i++) {
		int id;
		char name[10];
		printf("Enter the id: ");
		scanf("%d", &id);
		printf("Enter the name: ");
		scanf("%s", &name[0]);
		users->user_id = id;
		users->user_name = name;
		users++;
	}
	
}