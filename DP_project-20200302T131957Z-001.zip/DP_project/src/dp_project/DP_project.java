/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dp_project;

import java.io.IOException;

/**
 *
 * @author josiah
 */
public class DP_project {
    /**
     * @param args the command line arguments
     */
    //Creates a new IP_Gui
    public static void main(String[] args){
        new IP_GUI().setVisible(true);
    }

    //When the IP gui sends an IP it runs the rest of the program
    static void sendIP(String newip) throws IOException {
        int port = 6789;
        Client client = new Client();
        client.runClient(newip, port);
    }
}
