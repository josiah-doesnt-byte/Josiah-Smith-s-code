package dp_project; /**
 * Write a description of class ticket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Stack;
public class Event
{
    private String name;
    private int id;
    private int reqPoints;
    //private int maxTickets;
    private Stack<Ticket> ticketStack = new Stack<Ticket>();
    /**
     * Constructor for objects of class Items
     */
    public Event()
    {
        this("", 0, 0, 0);
    }

    public Event(String name, int id, int reqPoints, int maxTickets)
    {
        this.name = name;
        this.id = id;
        this.reqPoints = reqPoints;
    }

    public String getName()
    {
        return name;   
    }

    public int getId()
    {
        return id;
    }

    public int getReqPoints()
    {
        return reqPoints;
    }

    public int getNumTickets()
    {
        if(ticketStack.isEmpty()) return 0;
        else return ticketStack.size();
    }

    public void addTicket(Ticket ticket)
    {
        ticketStack.push(ticket);
    }

    public Ticket buyTicket()
    {
        if(getNumTickets() > 1)
        {
            return ticketStack.pop();
        }
        return null;
    }
    /*
    public void setName(String name)
    {
        this.name = name;   
    }

    public void setId(int id)
    {
    this.id = id;
    }
     
    
    public void setReqPoints(int reqPoints)
    {
        this.reqPoints = reqPoints;   
    }
    */
}