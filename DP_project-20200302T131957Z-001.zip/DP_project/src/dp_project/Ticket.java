package dp_project;

import java.io.Serializable;

/**
 * Write a description of class ticket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ticket implements Serializable
{
    private String name;
    private int id;
    //private int maxTickets;

    Ticket(String name, int id)
    {
        this.name = name;
        this.id = id;
        //this.maxTickets = maxTickets;
    }

    public String getName()
    {
        return name;   
    }

    public int getId()
    {
        return id;
    }

    public void setName(String name)
    {
        this.name = name;   
    }

    public void setId(int id)
    {
        this.id = id;
    }

}