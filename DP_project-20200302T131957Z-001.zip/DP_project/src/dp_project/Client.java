package dp_project;

//Import statements

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.Stack;

//Open class for the TCP Server
class Client {
    //Creates a User object to keep track of which user is currently logged in
    static User currentUser;
    //Creates an array of events to store all of the events
    static Event[] events;

    private static DataOutputStream toServer;
    private static DataInputStream fromServer;

    //Run server method, called by the DP_Project Class to begin the server
    void runClient(String ip, int port) throws IOException {
        //Connects client to the server using IP address (This needs to be generalized)
        //Creates client socket, to server and from server data streams, and object to server stream
        Socket clientSocket = new Socket(ip, port);
        //Defines data streams
        toServer = new DataOutputStream(clientSocket.getOutputStream());
        fromServer = new DataInputStream(clientSocket.getInputStream());
        //debug to find working dir
        //String currentDirectory = System.getProperty("user.dir");
        //System.out.println("The current working directory is " + currentDirectory);

        //Gets events from server
        toServer.writeInt(1);
        toServer.flush();
        String values = fromServer.readUTF();

        String[] lines = values.split(",");

        //Defines the array created earlier in the program
        events = new Event[3];
        //While the CSV has another line, the program splits the CSV into an array names line and creates a new Event
        //object in the events array using the split lines as parameters for the constructor
        events[0] = new Event(lines[1],Integer.parseInt(lines[2]),Integer.parseInt(lines[3]),Integer.parseInt(lines[4]));
        events[1] = new Event(lines[5],Integer.parseInt(lines[6]),Integer.parseInt(lines[7]),Integer.parseInt(lines[8]));
        events[2] = new Event(lines[9],Integer.parseInt(lines[10]),Integer.parseInt(lines[11]),Integer.parseInt(lines[12]));

        //Sets main menu to visible
        new Menu_GUI().setVisible(true);
    }

    //Register method, takes a username and password from the gui client and attempts to login using the information
    static boolean register(String username, String password) throws IOException {
        //Puts registration information into a string
        String information = username + "," + password;
        //writes the register request (2) to the server and then writes the information to the server
        toServer.writeInt(2);
        toServer.flush();
        toServer.writeUTF(information);
        toServer.flush();

        //Gets whether or not the server allowed the registration
        return fromServer.readBoolean();
    }

    //Login method, takes a given username and password from the client GUI and either logs in or doesnt depending on if
    //the given information exists in the CSV, returns false if the information doesnt match
    static boolean loginAttempt(String username, String password) {
        try {
            //Writes the login command to server
            toServer.writeInt(0);
            toServer.flush();
            //Reads user information from server
            //String string = fromServer.readUTF();
            Scanner scan = new Scanner(fromServer.readUTF());
            //While the CSV has a next line, the program takes that line and splits it into an array called line
            while (scan.hasNext()) {
                String[] line = scan.next().split(",");
                //If the username in the CSV and the password in the CSV match the given username and password
                //System.out.println("Entered username/pass: " + username + "/" + password + " real name/pass" + line[0] + "/" + line[1]);
                if (line[0].strip().equalsIgnoreCase(username.toLowerCase()) && line[1].strip().equals(password)) {
                    //Sets the current user to a new user object and sets its information the information in the CSV
                    setUser(new User());
                    currentUser.setName(line[0]);
                    currentUser.setId(line[1]);
                    currentUser.addPoints(Integer.parseInt(line[2]));
                    for (int i = 3; i < line.length; i++) {//start looking for events after the 4th comma
                        for(int j=0; j < events.length; j++){//iterate through the events
                            if(events[j].getName().replaceAll("\\s+", "").equals(line[i].replaceAll("\\s+", ""))){//match the event name in the userList csv with a real event in the event array and strip spaces
                                currentUser.addTicket(events[j]);//add matched ticket to users stack
                            }
                        }
                    }
                    //Returns true
                    return true;
                }
            }
            //If it catches any exception it just returns false
        } catch (Exception e) {
            System.out.println("Error: " + e);
            return false;
        }
        return false;
    }

    //Make history method to return the users purchase history
    static String makeHistory() {
        //Makes a temp stack of user tickets
        Stack<Ticket> temp = User.getTemp();
        //Creates a string of text from the users ticket stack
        String text = "History: ";
        while (temp.size() != 0) {
            text = text + temp.pop().getName() + ", ";
        }
        //returns the string
        return text;
    }

    //This should update the CSV when user information changes, such as when a user gets more points
    static void writeToCSV() throws IOException {
        //Write to csv command
        toServer.writeInt(3);
        toServer.flush();
        //sends the username then the points
        toServer.writeUTF(currentUser.getName());
        toServer.flush();
        toServer.writeInt(currentUser.getPoints());
        toServer.flush();
        /*
        toServer.writeInt(currentUser.getTemp().size());
        toServer.flush();


         */
        String tempString = "";
        Stack<Ticket> temp = User.getTemp();
        while (temp.size() != 0){
            tempString += "," + temp.pop().getName().replaceAll("\\s+", "");//pops off each event from the stack and write the name to the string
        }
        tempString += "\n";
        toServer.writeUTF(tempString);
        toServer.flush();




        //Sends the users Ticket stack to the server


    }

    //Get events method, this takes the event the user is trying to buy and returns the Event object that matches
    static Event getEvents(String attemptedEvent) {
        for (int x = 0; x < events.length; x++) {
            if (events[x].getName().equalsIgnoreCase(attemptedEvent)) {
                return events[x];
            }
        }
        return null;
    }

    //Sets the current user
    private static void setUser(User user) {
        currentUser = user;
    }

    static void close() throws IOException {
        toServer.writeInt(-1);
        toServer.flush();
    }
}