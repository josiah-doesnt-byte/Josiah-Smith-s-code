package dp_project;

import java.util.Stack;
public class User
{
    private String name;
    private String id;
    private int points;
    private static Stack<Ticket> tickets = new Stack<>();
    /**
     * Constructor for objects of class Items
     */
    User()
    {
        this("", "0");
    }

    private User(String name, String id)
    {
        this.name = name;
        this.id = id;
    }

    static Stack<Ticket> getTemp(){
        return (Stack<Ticket>)tickets.clone();
    }

    public String getName()
    {
        return name;   
    }

    public String getId()
    {
        return id;
    }

    int getPoints()
    {
        return points;
    }
    
    boolean purchaseTicket(Event event)//returns true if transaction went through
    {
        if((event.getReqPoints() * 1) <= this.getPoints())
        {
            this.removePoints(event.getReqPoints());
            tickets.push(new Ticket(event.getName(), event.getId()));
            return true;
        }
        return false;
    }

    void addTicket(Event event){
        tickets.push(new Ticket(event.getName(), event.getId()));
    }

    void addPoints(int addPoints){
        points = points + addPoints;
    }

    private void removePoints(int removePoints){
        points = points - removePoints;
    }

    public void setName(String name)
    {
        this.name = name;   
    }

    public void setId(String id)
    {
        this.id = id;
    }
}