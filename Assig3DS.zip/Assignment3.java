/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment3;

import java.io.*;
import java.util.Scanner;
import java.io.File;


/**
 *
 * @author smith_josiah
 */
public class Assignment3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(System.in);
        cars[] cars = new cars[5076];

//        System.out.println("Press 1 to read the file ");
//        System.out.println("Press 2 to do a linear search ");
//        System.out.println("Press 3 to do a binary search ");
//        System.out.println("Press 4 to quit ");
//        int ui = scan.nextInt();
       // while (ui!=4){

         //   if(ui==1){
        File fr = new File("C:\\Users\\josia\\Documents\\cars.txt");

        Scanner scan1 = new Scanner(fr);
        scan1.nextLine();
        int i = 0;
  
        while ((scan1.hasNextLine())) {
            cars myCar = new cars();
            String line = scan1.nextLine();
            String[] lineSplit = line.split(",");

            myCar.cityMPG = Integer.parseInt(lineSplit[0]);
            myCar.classification = lineSplit[1];
            myCar.driveLine = lineSplit[2];
            myCar.EngineType = lineSplit[3];
            myCar.fuelType = lineSplit[4];
            myCar.height = Integer.parseInt(lineSplit[5]);
            myCar.highwayMPG = Integer.parseInt(lineSplit[6]);
            myCar.horsePower = Integer.parseInt(lineSplit[7]);
            myCar.hybrid = Boolean.parseBoolean(lineSplit[8]);
            myCar.id = lineSplit[9];
            myCar.length = Integer.parseInt(lineSplit[10]);
            myCar.make = lineSplit[11];
            myCar.modelYear = lineSplit[12];
            myCar.numberOfFowardGears = Integer.parseInt(lineSplit[13]);
            myCar.torque = Integer.parseInt(lineSplit[14]);
            myCar.transmission = lineSplit[15];
            myCar.width = Integer.parseInt(lineSplit[16]);
            myCar.year = Integer.parseInt(lineSplit[17]);
            cars[i] = myCar;
            i++;
            System.out.println(line);
       // }
            }

           // else if (ui == 2) {
        System.out.println("What's the min?");
        int uiMin = Integer.parseInt(scan.nextLine());
        System.out.println("What's the max?");
        int uiMax = Integer.parseInt(scan.nextLine());
        System.out.println("What do you want to find?");
        String uiTarget = scan.nextLine();
        double t1 = System.nanoTime();
        cars wfg = new cars();
        wfg.id = uiTarget;
        linearSearch.linearSearch1(cars, uiMin, uiMax, wfg);
        double t2 = System.nanoTime();
        double finalTime = t2 - t1;
        System.out.println("The time it took to complete the linear search is " + finalTime + " nano seconds.");
        // }
        //else if (ui == 3){
        System.out.println("What's the min?");
        int uiMin1 = Integer.parseInt(scan.nextLine());
        System.out.println("What's the max?");
        int uiMax1 = Integer.parseInt(scan.nextLine());
        System.out.println("What do you want to find?");
        String uiTarget1 = scan.nextLine();
        double time1 = System.nanoTime();
        cars asd = new cars();
        asd.id = uiTarget1;
        binarySearch.binarySearch1(cars, uiMin1, uiMax1, asd);
        
        double time2 = System.nanoTime();
        double time = time2 - time1;
        System.out.println("The time it took to complete the binary search is " + time + " nano seconds.");
         }
         //else{
        // System.out.println("Error please make sure your input is correct.");
         
        // }
//          System.out.println("Press 1 to read the file ");
//        System.out.println("Press 2 to do a linear search ");
//        System.out.println("Press 3 to do a binary search ");
//        System.out.println("Press 4 to quit ");
//        ui = scan.nextInt();  
//        }
        
    }
//}

