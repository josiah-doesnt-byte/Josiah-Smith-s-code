-- Josiah Smith
-- assinment 3

-- 1. Returns the average of the dollar values of the salaries that were paid out on or after January 1, 2000
DROP PROCEDURE proc1;
delimiter //
CREATE PROCEDURE proc1(IN payday1 DATE, OUT dollars DOUBLE)
BEGIN
SELECT AVG(salaries.salary)
INTO dollars
FROM salaries
WHERE salaries.to_date <= payday1;
END //
delimiter ;
CALL proc1('2000-1-1', @averageSalary1);
SELECT @averageSalary1;
-- 2. Returns the average of the dollar values of the salaries that were paid out before January 1, 2000
DROP PROCEDURE proc2;
delimiter //
CREATE PROCEDURE proc2(IN payday2 DATE, OUT dollars DOUBLE)
BEGIN
SELECT AVG(salaries.salary)
INTO dollars
FROM salaries
WHERE salaries.to_date > payday2;
END //
delimiter ;
CALL proc1('2000-1-1', @averageSalary2);
SELECT @averageSalary2;
-- 3. Returns the outcome of dividing the return value from Step 1 by the return value from Step 2
DROP PROCEDURE proc3;
delimiter //
CREATE PROCEDURE proc3(OUT num1 DOUBLE)
BEGIN
	CALL proc1('2000-1-1', @doller1);
	CALL proc2('2000-1-1', @doller2);
	SET num1 = @doller1 / @doller2;
END //
delimiter ;
CALL proc3(@num1);
SELECT @num1;
-- 4. Returns the number of female employees that worked as department managers
DROP PROCEDURE proc4;
delimiter //
CREATE PROCEDURE proc4(OUT fdep INT)
BEGIN
SELECT COUNT(*)
INTO fdep
FROM employees, dept_manager
WHERE employees.emp_no = dept_manager.emp_no
	AND employees.gender = 'F'; 
END //
delimiter ;
CALL proc4(@totalfdep);
SELECT @totalfdep;
-- 5. Returns the total number of female employees.
DROP PROCEDURE proc5;
delimiter //
CREATE PROCEDURE proc5(OUT femp INT)
BEGIN
SELECT COUNT(*)
INTO femp
FROM employees
WHERE employees.gender = 'F';
END //
delimiter ;
CALL proc5(@totalfem);
SELECT @totalfem;
-- 6. Returns the outcome of dividing the return value from Step 4 by the return value from Step 5
DROP PROCEDURE proc6;
delimiter //
CREATE PROCEDURE proc6(OUT num1 DOUBLE)
BEGIN
	CALL proc4(@total1);
	CALL proc5(@total2);
	SET num1 = @total1 / @total2;
END //
delimiter ;
CALL proc6(@y);
SELECT @y;
-- 7. Returns the number of employees that served in three or more positions
DROP PROCEDURE proc7;
delimiter //
CREATE PROCEDURE proc7(OUT pos3 INT)
BEGIN
-- DECLARE cnt INT DEFAULT 0;
SELECT emp_no, COUNT(*) AS cnt
FROM titles
GROUP BY emp_no;

SELECT COUNT(cnt) 
INTO pos3
FROM titles
WHERE cnt > 2;
END //
delimiter ;
CALL proc7(@z);
SELECT @z;
-- 8. Returns the number of employees that served in research
DROP PROCEDURE proc8;
delimiter //
CREATE PROCEDURE proc8(OUT resEmp INT)
BEGIN
SELECT COUNT(*)
INTO resEmp
FROM employees, dept_emp, departments
WHERE employees.emp_no = dept_emp.emp_no
	AND dept_emp.dept_no = departments.dept_no
	AND departments.dept_name = 'Research';
END //
delimiter ;
CALL proc8(@x);
SELECT @x;
-- 9. Computes the sum of the return values from Step 7 and Step 8. Returns the outcome of dividing this sum by the total number of employees.
DROP PROCEDURE proc9;
delimiter //
CREATE PROCEDURE proc9(OUT finalNum DOUBLE)
BEGIN
    DECLARE total3 INT DEFAULT 0;
    DECLARE totalEmp INT DEFAULT 0;
    SELECT COUNT(*)
	INTO totalEmp
	FROM employees;
	-- CALL proc7(@total1);
	CALL proc8(@total2);
	-- SET total3 = @total + @total2;
    -- SET finalNum = total3 / totalEmp;
     SET finalNum = @total2 / totalEmp;
END //
delimiter ;
CALL proc9(@num1);
SELECT @num1;
-- 10. Compute the rating of the company as the product (or the sum) of the return values from Step 3, Step 6 and Step 9. Prints Very Good if the ratio  is at or above 0.9. Print Good if the ratio is between 0.8 and 0.89. Print average if the ratio is between 0.7 and 0.79. Print Poor if the ratio is less than 0.7.
DROP PROCEDURE proc10;
delimiter //
CREATE PROCEDURE proc10()
BEGIN
	DECLARE total1 INT DEFAULT 0;
	DECLARE total2 INT DEFAULT 0;
    DECLARE total3 INT DEFAULT 0;
    DECLARE finalNum INT DEFAULT 0;
    DECLARE vg VARCHAR(30);
    DECLARE g VARCHAR(30);
    DECLARE a VARCHAR(30);
    DECLARE p VARCHAR(30);
    DECLARE e VARCHAR(30);
    SET vg = 'Very Good';
    SET g = 'Good';
    SET a = 'Average';
    SET p = 'Poor';
    SET e = 'Error';
    CALL proc3(total1);
	CALL proc6(total2);
    -- commented out so it will not crash
    -- this error is due to #7
	-- CALL proc9(total3);
	SET finalNum = total1 + total2 + total3;
    IF finalNum >= 0.9 THEN
		SELECT vg;
        -- very goood
    ELSEIF finalNum >= 0.8 & finalNum <= 8.9 THEN
		SELECT g;
        -- good
    ELSEIF finalNum >= 0.7 & finalNum <= 7.9 THEN    
		SELECT a;
        -- average 
	ELSEIF finalNum > 0.7 THEN  
		SELECT p;
        -- poor
    ELSE
		SELECT e;
        -- error
        END IF;
END //
delimiter ;
CALL proc10();
-- no return only print 
