
/**
 * Write a description of class NewSlot here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NewSlot
{
    private Token token;
    private NewSlot[] hood;
    /**
     * Constructor for objects of class NewSlot
     */
    public NewSlot()
    {
        hood = new NewSlot[8];
    }

    public void setToken(Token token)
    {
        this.token = token;
    }

    public Token getToken()
    {
        return this.token;
    }

    public void setConnection(NewSlot slot, Direction direction)
    {
        hood[direction.ordinal()] = slot;
    }

    public NewSlot getConnection(Direction direction)
    {
        return hood[direction.ordinal()];
    }

    public int numberOfNeighbors()
    {
        int counter = 0;
        for(int index = 0; index < hood.length; index++)
        {
            if(hood[index] != null)
            {
                counter++;
            }
        }
        return counter;
    }

    public String show()
    {
        // Enable the line below for normal operation
        return (token == null?"_":token.toString());
        // Enable the line below for testing
        //return (token == null?"" + numberOfNeighbors():token.toString());
    }

    public String print()
    {
        NewSlot east = getConnection(Direction.E);
        NewSlot south = getConnection(Direction.S);
        NewSlot west = getConnection(Direction.W);
        String temp = show() + "|" + (east == null?"":east.print());
        if(west == null && south != null)
        {
            temp += "\n" + south.print();
        }
        return temp;
    }

    public boolean drop(Token token)
    {
        if(getToken() != null) // I already have a token
        {
            return false;
        }
        else
        { // I don't have a token
            NewSlot south = getConnection(Direction.S);
            if(south == null) // There is nothing under me
            {
                setToken(token); // I keep the token
                // I changed the number from 4 to 3 because in the method checkConnect I am checking the connections which would be 3
                return checkConnect(3, null, getToken().getColor());
            }
            else
            {
                if(south.getToken() == null)
                {
                    return south.drop(token); // drop the token down
                }
                else
                {
                    setToken(token);
                    // I changed the number from 4 to 3 because in the method checkConnect I am checking the connections which would be 3
                    return checkConnect(3, null, getToken().getColor());
                }
            }
        }
    }

    // You check whether you connected the number of tokens in a row, column or diagonals
    // I made the method checkConnect public so that I could call it in the NewGrid class
    public boolean checkConnect(int number, Direction d, Color c)
    {
        int temp = number;
        NewSlot northEast = getConnection(Direction.NE);
        int nE = 0;
        NewSlot east = getConnection(Direction.E);
        int e = 0;
        NewSlot southEast = getConnection(Direction.SE);
        int sE = 0;
        NewSlot south = getConnection(Direction.S);
        int s = 0;
        NewSlot southWest = getConnection(Direction.SW);
        int sW = 0;
        NewSlot west = getConnection(Direction.W);
        int w = 0;
        NewSlot northWest = getConnection(Direction.NW);
        int nW = 0;
        boolean connect = false;

        if(0 == number && (nE == temp || e == temp && sE == temp && s == temp && sW == temp && w == temp &&  nW == temp))
        {
            connect = connect || true; // won 
        }

        if(d == null || d == Direction.NE)
        {
            if(northEast != null && northEast.getToken() != null && c == northEast.getToken().getColor()) {
                connect = connect || northEast.checkConnect(--number, Direction.NE, c);
                nE++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.E)
        {
            if(east != null && east.getToken() != null && c == east.getToken().getColor()) {
                connect = connect || east.checkConnect(--number, Direction.E, c);
                e++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.SE)
        {
            if(southEast != null && southEast.getToken() != null && c == southEast.getToken().getColor()) {
                connect = connect || southEast.checkConnect(--number, Direction.SE, c);
                sE++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.S)
        {
            if(south != null && south.getToken() != null && c == south.getToken().getColor()) {
                connect = connect || south.checkConnect(--number, Direction.S, c);
                s++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.SW)
        {
            if(southWest != null && southWest.getToken() != null && c == southWest.getToken().getColor()) {
                connect = connect || southWest.checkConnect(--number, Direction.SW, c);
                sW++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.W)
        {
            if(west != null && west.getToken() != null && c == west.getToken().getColor()) {
                connect = connect || west.checkConnect(--number, Direction.W, c);
                w++;
            } 
            else {
                connect = connect || false;
            }
        }

        if(d == null || d == Direction.NW)
        {
            if(northWest != null && northWest.getToken() != null && c == northWest.getToken().getColor()) {
                connect = connect || northWest.checkConnect(--number, Direction.NW, c);
                nW++;
            } 
            else {
                connect = connect || false;
            }
        }
        return connect;
    }

    // This is still not working properly
    public void createGrid(int rows, int columns)
    {
        NewSlot east = getConnection(Direction.E);
        if(east == null)
        {
            east = new NewSlot();
        }
        NewSlot southEast = null;
        System.out.println("Rows: " + rows + " Columns: " + columns);
        if(columns > 1)
        {
            connectSlots(this, east, Direction.E, Direction.W);
            System.out.println(rows + " " + columns + " East-SouthEast");
            east.createGrid(rows, columns - 1);
            System.out.println(rows + " " + columns + " Return to East-SouthEast");
            southEast = east.getConnection(Direction.S);
            if(southEast == null)
            {
                System.out.println("Error!");
            }
            else
            {
                connectSlots(this, southEast, Direction.SE, Direction.NW);
            }
        }

        if(rows > 1)
        {

            NewSlot south = getConnection(Direction.S);
            if(south == null)
            {
                south = new NewSlot();
            }
            connectSlots(this, south, Direction.S, Direction.N);
            if(southEast != null)
            {
                connectSlots(south, southEast, Direction.E, Direction.W);
            }
            System.out.println(rows + " " + columns + " South");
            south.createGrid(rows - 1, columns);                
            System.out.println(rows + " " + columns + " Return to South");
            if(southEast != null)
            {
                connectSlots(east, south, Direction.SW, Direction.NE);
            }
        }
    }

    public static void connectSlots(NewSlot slot1, NewSlot slot2, Direction direction1, Direction direction2)
    {
        System.out.println("Slot1: " + slot1 + ", Slot2: " + slot2 + ", Direction1: " + direction1 + ", Direction2: " + direction2);
        slot1.setConnection(slot2, direction1);
        slot2.setConnection(slot1, direction2);
    }
}
