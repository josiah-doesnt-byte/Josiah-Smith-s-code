
/**
 * Enumeration class Direcion - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Direction
{
    N, NE, E, SE, S, SW, W, NW
}
