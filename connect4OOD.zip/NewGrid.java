
/**
 * Write a description of class NewGrid here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NewGrid
{
    private int rows;
    private int columns;
    private NewSlot entry;
    private NewSlot[][] grid; 
    private Token token;
    /**
     * Constructor for objects of class NewGrid
     */
    public NewGrid()
    {
        this(6, 7);
    }

    public NewGrid(int rows, int columns)
    {
        // Create the array to serve as scaffolding
        grid = new NewSlot[rows][columns];
        for(int row = 0; row < rows; row++)
        {
            for(int column = 0; column < columns; column++)
            {
                grid[row][column] = new NewSlot();
            }
        }

        //Connect the cells
        entry = grid[0][0];
        for(int row = 0; row < rows; row++)
        {
            for(int column = 0; column < columns; column++)
            {
                for(int index = 0; index < 8; index++)
                {
                    try
                    {
                        grid[row][column].setConnection(grid[row - computeRowOffset(index)][column + computeColumnOffset(index)], Direction.values()[index]);
                    }
                    catch(IndexOutOfBoundsException e)
                    {
                    }
                }
            }
        }

    }

    private static int computeColumnOffset(int ordinal)
    {
        return (ordinal == 0 || ordinal == 4)?0:(ordinal < 4)?1:-1;
    }

    private static int computeRowOffset(int ordinal)
    {
        return computeColumnOffset((ordinal + 2) % 8);
    }

    public Token getToken()
    {
        return this.token;
    }
    // drops the token in the appropriate column
    public boolean drop(Token token, int column)
    {
        //int x = 0;
        //int y = 0;
        
        if(column > grid[0].length - 1)
        {
        return false;
        }
        else{
        return grid[0][column].drop(token); 
        }
        
        // if(grid[0][column].getToken() == null)
        // {
            // int row = 0;
            // boolean placed = false;
            // while(!placed)
            // {
                // if(row < grid.length - 1 && grid[row + 1][column].getToken() == null)
                // {
                    // row++;
                // }
                // else
                // {
                    // grid[row][column].setToken(token);
                    // placed = true;
                    // x = row;
                    // y = column;
                // }
            // }
        // }
        // Direction needs to equal the direction where the connect it
        //return grid[x][y].checkConnect(3, null, grid[x][y].getToken().getColor());
    }

    public String show()
    {
        return entry.print();
    }

}

