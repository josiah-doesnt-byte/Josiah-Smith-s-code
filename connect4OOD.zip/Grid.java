
/**
 * Write a description of class Grid here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Grid
{
    private Slot[][] grid;
    /**
     * Constructor for objects of class Grid
     */
    public Grid()
    {
        this(6, 7);
    }
    
    public Grid(int rows, int columns)
    {
        grid = new Slot[rows][columns];
        for(int row = 0; row < rows; row++)
        {
            for(int column = 0; column < columns; column++)
            {
                grid[row][column] = new Slot();
            }
        }
    }
    
    public void drop(Token token, int column)
    {
        if(column > grid[0].length - 1)
        {
            return;
        }
        if(grid[0][column].getToken() == null)
        {
            int row = 0;
            boolean placed = false;
            while(!placed)
            {
                if(row < grid.length - 1 && grid[row + 1][column].getToken() == null)
                {
                    //System.out.println("Row: " + row);
                    row++;
                }
                else
                {
                    grid[row][column].setToken(token);
                    placed = true;
                }
            }
        }
    }
    
    public String show()
    {
        String temp = "";
        for(int row = 0; row < grid.length; row++)
        {
            for(int column = 0; column < grid[row].length; column++)
            {
                temp += grid[row][column].show();
            }
            temp += "\n";
        }
        return temp;
    }
}
