/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pac;
import java.io.*;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author josiah smith
 */

public class DatatStructureAssignment2 {

    /**
     * @param args the command line arguments
     */ //main program where the menu is and it calls the game to play it 
    public static void main(String[] args) throws FileNotFoundException {
        HiScoresLL highScoreList = new HiScoresLL();
        System.out.println("Select 1 if you want to play");
        System.out.println("Select 2 if you want to see your highscore");
        System.out.println("Select 3 twice if you want to quit and save to a new file ");
        Scanner scan2 = new Scanner(System.in);
        int us = scan2.nextInt();
        while( us != 3){
           if(us==1)
           {
               
           System.out.println(mathGame());
           }
           else if(us==2){
           highScoreList.display();
           }

     System.out.println("Select 1 if you want to play");
     System.out.println("Select 2 if you want to see your highscore");
     System.out.println("Select 3 if you want to quit and save to a new file ");      
     us = scan2.nextInt();
    
    }
        //saves to the file highScores.txt
    File file1 = new File("./highScores.txt");
    PrintWriter pw = new PrintWriter(file1);
    String allScores = highScoreList.toString();
    pw.print(allScores);
    pw.close();
            
            
            // TODO code application logic here
        
    }
    //The math game that asks simple addition questions and finds your high score
   public static GameEntry mathGame() {
       HiScoresLL highScoreList = new HiScoresLL();
       
        int score = 0;
        Scanner scan1 = new Scanner(System.in);
        Random rand = new Random();
        //asks for the the user's name
        System.out.println("What is your name?");
        String userName = scan1.nextLine();
         
        System.out.println("Welcome to the math game!");
        System.out.println("Select 1 if you want to play");
        System.out.println("Select 2 if you want to see your highscore");
        System.out.println("Select 3 if you want to quit!");
        //asks for the number to start 
        int user1 = scan1.nextInt();
        //Game itself
        while (user1 != 3){
            if(user1==1)
            {
                
                int num1 = rand.nextInt(10);
                int num2 = rand.nextInt(10);
                System.out.println("Thank you for playing the game and good luck");
                System.out.println(num1 + "+" + num2);
                int user2 = scan1.nextInt();
                if(user2 == num1 + num2 )
                {
                    System.out.println("Correct");
                    score ++; 
                }
                else{
                    System.out.println("Incorrect");
                    
               }
                System.out.println("Select 1 if you want to play");
                System.out.println("Select 2 if you want to see your highscore");
                System.out.println("Select 3 if you want to quit!");
                user1 = scan1.nextInt();
                
                
            }
            if(user1==2)
            {
                System.out.println("Your high score is " + score);
                System.out.println("Select 1 if you want to play");
                System.out.println("Select 2 if you want to see your highscore");
                System.out.println("Select 3 if you want to quit!");
                user1 = scan1.nextInt();
            }
            
            
           
           
   }
     // GameEntry object created and added to the highScoreList linked list
     GameEntry player1 = new GameEntry(userName, score);
     highScoreList.add(player1);
     return player1;    
   }
   
}
      
  

