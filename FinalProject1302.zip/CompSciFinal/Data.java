
/**
 * Write a description of interface Data here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.IOException;

public interface Data
{
    //these two methods will be used by every class to scrape data
    //and get file input
    public void getInfo(String userState) throws IOException;

}
