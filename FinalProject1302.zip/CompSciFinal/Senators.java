
/**
 * Write a description of class Senators here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.IOException;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
public class Senators implements Data
{
    public void getInfo(String userState) throws IOException
    {
        //I know this is really rough, but we couldn't get the states with two words in the name
        //to work with the senator URLs unless the states were shortened
        userState = userState.replaceAll("new hampshire", "NH");
        userState = userState.replaceAll("new york", "NY");
        userState = userState.replaceAll("new jersey", "NJ");
        userState = userState.replaceAll("new mexico", "NM");
        userState = userState.replaceAll("north carolina", "NC");
        userState = userState.replaceAll("north dakota", "ND");
        userState = userState.replaceAll("rhode island", "RI");
        userState = userState.replaceAll("south carolina", "SC");
        userState = userState.replaceAll("south dakota", "SD");
        userState = userState.replaceAll("west virginia", "WV");
        
        String url = "https://www.govtrack.us/congress/members/" + userState;
        Document document = Jsoup.connect(url).get();
        
        Elements senators = document.select("p.moc").select("a");
        Elements facts = document.select("div.info");
        
        for(Element senator : senators)
        {
            System.out.println(senator.ownText());
        
        }
        
    }
}
