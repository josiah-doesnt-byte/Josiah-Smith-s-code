
/**
 * Write a description of class Main here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import org.jsoup.*;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) throws Exception
    {
        Senators s1 = new Senators();
        GunLaws gl1 = new GunLaws();
        GunViolence gv1 = new GunViolence();
        Scanner sc = new Scanner(System.in);
        
        //replaces spaces in entries with hypen so they will work with the URL
        //here is where the main program begins
        System.out.println("Welcome to the gun laws and statistics program! Enter a state to get gun laws and statistics.");
        String userState = sc.nextLine();
        while(!userState.equalsIgnoreCase("quit")){
        try{
            
            
                System.out.println("Gun laws: ");
                gl1.getInfo(userState);
                System.out.println("");
                System.out.println("Gun violence statistics: ");
                gv1.getInfo(userState);
                System.out.println("");
                System.out.println("Congress (senate are top two and reps are below that): ");
                s1.getInfo(userState);
                System.out.println("Enter another state or type 'quit' to quit.");
                userState = sc.nextLine();
            
        }
        catch (HttpStatusException h){
            System.out.println("That state doesn't exist! Try again!");
            userState = sc.nextLine();
        }
    }
        
    }
}
