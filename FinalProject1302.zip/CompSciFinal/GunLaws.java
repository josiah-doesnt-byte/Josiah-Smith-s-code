
/**
 * Write a description of class GunLaws here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.IOException;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
public class GunLaws implements Data
{
    
    public void getInfo(String userState) throws IOException
    {
        
        userState = userState.replace(' ', '-');

        //gets the page of gun law states by userState(to be entered in main)
        String url = "https://www.nraila.org/gun-laws/state-gun-laws/" + userState;
        Document document = Jsoup.connect(url).get();
        
        //gets items from selected html elements, nested in website source code. 
        //This is where the laws are located on the website
        Elements typesOfGuns = document.select("table.gun_laws_overview").select("th");
        Elements facts = document.select("table.gun_laws_overview").select("tr").select("td");
        //converts HTML elements to strings
        String textFacts = facts.text();
        String textGuns = typesOfGuns.text();
        for (Element fact : facts)
        {
        //TODO: Find a way to seperate handgun and rifle laws
        System.out.println(fact.ownText());
        }
        
    }

}
