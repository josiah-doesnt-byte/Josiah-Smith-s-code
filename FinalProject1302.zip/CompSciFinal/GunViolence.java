
/**
 * Write a description of class GunViolence here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.*;
import java.lang.String.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
public class GunViolence
{
    public void getInfo(String userState) throws IOException
    {
        BufferedReader in = new BufferedReader(new FileReader("GunViolenceByState.txt"));
        File f = new File("GunViolenceByState.txt");
        String test = in.readLine();
        while(in.readLine() != null)
        {
            for(int i = 0; i <= 250; i++){
            if (userState.equalsIgnoreCase(in.readLine()))
            {
                for(int j = 0; j <= 4; j++){
                System.out.println(in.readLine());
            }
            }
        }
        }
    }
}

