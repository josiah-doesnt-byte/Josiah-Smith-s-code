-- 1. (5 points) Develop a stored procedure PROC1 that accepts an employee number, a dollar value, a from date and a to date and insert then as a row into the salaries table.
DROP PROCEDURE proc1;
delimiter //

Create PROCEDURE proc1(IN num INT, IN dollar INT, IN fDate DATE, IN tDate DATE)
BEGIN
INSERT INTO salaries (emp_no, salary, from_date, to_date) 
VALUES (num, dollar, fDate, tDate);
END //
delimiter ;
-- 2. (5 points) Develop a stored procedure PROC2 that accepts an employee number, a dollar value, a from date and a to date and updates the dollar value of the employee's salary.
DROP PROCEDURE proc2;

delimiter //
Create PROCEDURE proc2(IN num INT, IN dollar INT, IN from_date DATE, IN to_date DATE)
BEGIN
UPDATE salaries 
SET salary = dollar
Where emp_no = num;
END //
delimiter ;
-- 3. (5 points) Develop a BEFORE INSERT trigger TRIGGER1 on the salaries table
-- If the new from_date is greater than the new to_date, set the new from_date to equal to new to_date. 
DROP TRIGGER t1;

delimiter //
CREATE TRIGGER t1 BEFORE UPDATE ON salaries
FOR EACH ROW
BEGIN
	IF New.from_date > New.to_date
	THEN SET New.from_date = New.to_date;
END IF;
END //
delimiter ;
-- 4. (5 points) Develop an AFTER INSERT trigger TRIGGER2 on the salaries table 
-- Insert the salary row that was just inserted into a salaries_backup table. (You may have to first create and add a salaries_backup table to the employees database)
CREATE TABLE salaries_backup (emp_no INT, salary INT, from_date DATE, to_date DATE);
DROP TRIGGER t2;

delimiter //
CREATE TRIGGER t2 AFTER INSERT ON salaries
FOR EACH ROW
BEGIN
-- INTO salaries_backup;
INSERT INTO salaries_backup (emp_no, salary, from_date, to_date) VALUES ( New.emp_no, New.salary, New.from_date, New.to_date) ;

END //
delimiter ;

INSERT INTO employees.salaries VALUES 
(5);
-- 5. (5 points) Develop a BEFORE UPDATE trigger TRIGGER3 on the salaries table
-- If the new dollar value to be updated is negative, set it to 0. 
DROP TRIGGER t3;

delimiter //
CREATE TRIGGER t3 BEFORE UPDATE ON salaries
FOR EACH ROW
BEGIN
	IF New.salary > 0
    THEN SET New.salary = 0;
END IF;   
END //   
delimiter ;
-- 6. (5 points) Develop a AFTER UPDATE trigger TRIGGER4 on the salaries table 
-- If the row that was updated is already in the salaries_backup table, update it there as well
DROP TRIGGER t4;

delimiter //
CREATE TRIGGER t4 AFTER UPDATE ON salaries
FOR EACH ROW
BEGIN
UPDATE salaries_backup
Set salary = New.salary
WHERE emp_no = New.emp_no;
END //
delimiter ;
-- 7. (5 points) Call PROC1
CALL proc1(10005, 5, '2020-4-2', '2017-3-2');
-- 8. (5 points) Call PROC2
CALL proc2(10002, 5, '2020-4-2', '2017-3-2');
