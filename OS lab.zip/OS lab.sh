
echo "step 1"
df
echo

echo "step 2"
df -i
echo

echo "step 3"
touch f1
echo

echo "step 4"
ls -li
echo

echo "step 5"
df
echo
df -i
echo

echo "step 6"
ln f1 f2
echo

echo "step 7"
ls -li
echo
df
echo
df -i
echo

echo "step 8"
for in in {1..70}
do
        echo "hello world" >> f1
done
echo

echo "step 9"
ls -li
echo
df
echo
df -i
echo

echo "step 10"
rm f1
rm f2
echo

echo "step 11"
touch f1
echo

echo "step 12"
ls -li
echo
df
echo
df -i
echo

echo "step 13"
ln -s f1 f2
echo

echo "step 14"
ls -li
echo
df
echo
df -i
echo

echo "step 15"
for i in {1..50}
do
        echo "hello world 2" >> f1
done
echo

echo "step 16"
ls -li
echo
df
echo
df -i
echo

echo "step 17"
rm f1
rm f2
echo