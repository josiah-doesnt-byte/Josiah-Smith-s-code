#include <time.h>
#include <stdio.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>
#include <fcntl.h>

#define LOCKSIZE 4
#define ARRAY_SIZE 10

sem_t *mutex1;
sem_t *mutex2;

void parentCritical();
void childCritical();

//We will share an integer lock
int main(int argc, char* argv[])
{
    int arrayInt [ARRAY_SIZE];
        printf("start\n");
    mutex1 = sem_open("/one", O_CREAT | O_EXCL, 0644, 1);
    mutex2 = sem_open("/two", O_CREAT | O_EXCL, 0644, 1);
    sem_unlink ("/one");
    sem_unlink ("/two");
    // Tell the process how many *bytes* you need for the shared memory
    //We need 4 bytes
    const int segment_size = LOCKSIZE;

    //shared memory
    int segment_id = shmget(IPC_PRIVATE, segment_size, 0666);

    // pointer for the segment_id
    int* lockptr = (int *) shmat(segment_id, NULL, 0);

        printf("before fork\n");
    // fork
    pid_t pid = fork();
    //From this point on, two processed will run the following code
        int i = 1;
        while(i = 1)
{
    if (pid == 0){ //Child process
        //Pre-entry protocol
                printf("child process");
                sem_wait(mutex1);
                sem_wait(mutex2);
                //child critical
                childCritical(arrayInt);
                // Post-exit protocol
                sem_post(mutex1);
                sem_post(mutex2);
                }
        else if (pid > 0){//Parent process
                //Pre-entry protocol
                printf("parent process");
                sem_wait(mutex1);
                sem_wait(mutex2);
                // parent critical
                parentCritical(arrayInt);
                // Post-exit protocol
                sem_post(mutex1);
                sem_post(mutex2);
                }
    else{
        printf("Fork failed.");
        }
}
sem_destroy(mutex1);
sem_destroy(mutex2);

//return 0;
}

void childCritical(int array[]) //child critical
 {
                                for(int j=0; j < ARRAY_SIZE; j++)
                                {
                                        if(array[j] > 100)
                                        {
                                                array[j] = 0;
                                                printf("Process has exeeded the limit on system calls\n");
                                        }
                                }
}

void parentCritical(int array[]) //parent critical
{
                        srand(time(NULL));
                        int what = rand() %150;
                        int where = rand() %11;
                        array[where] = what;
}