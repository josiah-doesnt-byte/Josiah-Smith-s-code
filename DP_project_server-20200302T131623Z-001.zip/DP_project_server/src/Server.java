import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileWriter;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetAddress;
import java.util.Scanner;

import com.opencsv.CSVWriter;

/*----------------------------------------------------------------------------------------------------------------------
Class header, this is the client, AKA: what the user will see, this class handles only user input and handles NONE
of the data handling. For security sake, the server is the only thing that handles data like user information, passwords,
event data, and other such. This class purely makes a connection to the server, and allows the client to send requests
to the server.
 *///-------------------------------------------------------------------------------------------------------------------
class Server {
    private DataInputStream fromClient;
    private DataOutputStream toClient;

    void runServer() throws IOException {
        //Defines the server socket on port 6789
        /*
    Initial objects used in the program, a scanner for user input, one socket for the client to connect with, a
    buffered reader to get information from the user(maybe temp), and a data input/output stream for data to and from
    the server.
     */
        //Creates the server socket, client socket, and data streams
        ServerSocket serverSocket = new ServerSocket(6789);
        System.out.println("Running server on IP: " + InetAddress.getLocalHost());
        System.out.println("Waiting for connection: ");
        //Waits for connection from a client
        Socket clientSocket = serverSocket.accept();
        System.out.println("Client Connected at IP: ");
        System.out.println(clientSocket.getInetAddress().getHostAddress());
        System.out.println("Listening for commands");
        //Defines the data streams
        fromClient = new DataInputStream(clientSocket.getInputStream());
        toClient = new DataOutputStream(clientSocket.getOutputStream());
        //Sets request variable to some unused number
        int request = 10;

        //While the request isnt -1 (Close Request)
        while (request != -1) {
            //Request 0 is for getting user information
            //System.out.println("Current request num: " + request);
            if (request == 0) {
                System.out.println("Request for users detected, sending...");
                sendUsers();
                System.out.println("Done!");
                //Request 1 is for getting event information
            } else if (request == 1) {
                System.out.println("Request for events detected, sending...");
                sendEvents();
                System.out.println("Done!");
                //Request 2 is for writing to the user CSV (Registration)
            } else if (request == 2) {
                System.out.println("Request to write detected, writing...");
                writeNewUser();
                System.out.println("Done!");
                //Request 3 is for updating the user CSV (When you buy points or something)
            } else if (request == 3) {
                System.out.println("Request to update detected, updating...");
                updateUsers();
                System.out.println("Done!");
            }
            //Repeats waiting for requests until the server is closed
            request = fromClient.readInt();
        }
    }

    //Used to register a new user
    private void writeNewUser() throws IOException {
        //Reads the new user information sent from the user
        String[] info = fromClient.readUTF().split(",");
        //Opens the file, userlist CSV to read user information
        File file = new File("userList.csv");
        Scanner scan = new Scanner(file);
        while (scan.hasNextLine()) {
            String[] line = scan.nextLine().split(",");
            if (info[0].equalsIgnoreCase(line[0])) {
                toClient.writeBoolean(false);
                toClient.flush();
            }
        }
        //Creates a FileWriter object to write to the user list
        FileWriter outputFile = new FileWriter(file, true);
        //Defines a CSV writer to write using the FileWriter (The CSV writer is made specifically to write in a CSV format)
        CSVWriter writer = new CSVWriter(outputFile, ',', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END);
        //Array of strings called data to store the incoming registration information
        String[] data = {info[0], info[1], "500"};
        //Writes that array of information to the CSV to register the new user
        writer.writeNext(data);
        //Closes the writer
        writer.close();
        //Writes result to the client
        toClient.writeBoolean(true);
        //Closes the scanner so another process can use the user file
        scan.close();
    }

    //Update users to add new ticket amounts
    private void updateUsers() throws IOException {
        //Gets user information from the server
        String currentUserName = fromClient.readUTF();
        int currentUserPoints = fromClient.readInt();
        //int sizeOfStack = fromClient.readInt();
        //Stack<Ticket> temp = (Stack<Ticket>) objectFromClient.readObject();
        //File object to store the location of the eventList CSV
        File file = new File("userList.csv");
        //Scanner object to read from the file
        Scanner scan = new Scanner(file);

        //Defines string to hold user data temporarily
        String tempData = "";
        //Counter to iterate through the array
        //While the CSV has another line, the program splits the CSV into an array names line and creates a new Event
        //object in the events array using the split lines as parameters for the constructor
        while (scan.hasNextLine()) {
            String[] line = scan.nextLine().split(",");
            if (line[0].equals(currentUserName)) {//used to find the current user
                tempData += line[0] + "," + line[1] + "," + currentUserPoints;//write the data from the array into a string and use the updated point value
                //Makes a temp stack of user tickets
                //Stack<Ticket> temp = currentUser.getTemp();
                /*
                while (temp.size() != 0) {
                    tempData += "," + temp.pop().getName().replaceAll("\\s+", "");//pops off each event from the stack and write the name to the strinG
                }
                tempData += "\n";
                 */
                //System.out.println("if: line[0]: " + line[0] + " crrname: " + currentUserName);
                tempData += fromClient.readUTF();
            } else {
                //System.out.println("else: line[0]: " + line[0] + " crrname: " + currentUserName);

                tempData += line[0] + "," + line[1] + "," + line[2];//not our user so use existing values
                for (int i = 3; i < line.length; i++) {
                    tempData += "," + line[i];
                }
                tempData += "\n";
            }
            //System.out.println(tempData);
        }
        //Creates a FileWriter object to write to the user list
        FileWriter writer = new FileWriter(file, false);
        //Defines a CSV writer to write using the FileWriter (The CSV writer is made specifically to write in a CSV format)
        writer.write(tempData);
        //Closes the writer
        writer.close();
        //Closes scanner
        scan.close();
    }

    //Sends the user list to the client as a comma delimited string
    private void sendUsers() throws IOException {
        String string = "";
        File file = new File("userList.csv");
        Scanner scan = new Scanner(file);

        while (scan.hasNextLine()) {
            string = string + scan.nextLine() + "\n";
        }
        //System.out.println(string);

        toClient.writeUTF(string);
        toClient.flush();
        scan.close();
    }

    //Same thing as sendUsers but for events
    private void sendEvents() throws IOException {
        String string = null;
        File file = new File("eventList.csv");
        Scanner scan = new Scanner(file);

        while (scan.hasNextLine()) {
            string = string + "," + scan.nextLine();
        }

        assert string != null;
        toClient.writeUTF(string);
        toClient.flush();
        scan.close();
    }
}
