import java.io.Serializable;

/**
 * Write a description of class ticket here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ticket implements Serializable
{
    //private int maxTickets;

    private Ticket(String name, int id, int reqPoints)
    {
        //this.maxTickets = maxTickets;
    }

}