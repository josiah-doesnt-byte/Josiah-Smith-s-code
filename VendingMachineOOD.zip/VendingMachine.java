import java.util.HashMap;

/**
 * Write a description of class VendingMachine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class VendingMachine 
{
    private HashMap<String, ProductContainer> trays;
    private CoinContainer insertedCoins;
    public Container<Product> dispenser;
    
    public VendingMachine()
    {
        trays = new HashMap<String, ProductContainer>();
        trays.put("A1", ProductContainer.makeContainerWith(new Product("Cheetos", 25), 10));
        trays.put("A2", ProductContainer.makeContainerWith(new Product("Tostitos", 55), 12));
        trays.put("B2", ProductContainer.makeContainerWith(new Product("Oreo", 70), 15));
        
        insertedCoins = CoinContainer.defaultContainer();
        
        dispenser = new Container<Product>();
    }
    
    public void insert(Coin coin)
    {
       insertedCoins.add(coin);
       
    }
    
    public void enterLabel(String label)
    {
        Product sample = trays.get(label).remove();
        if(trays.containsKey(label)) // legit label
        {
            if(insertedCoins.getGrandTotalValue() >= sample.getValue()) // value is valid
            {
                dispenser.add(sample);
            }
        }
        // should check if the grandtotalvalue is greater than or equal to the value of the label
        // use the label to get from the tray ( make sure the label is legit)
        // using the price of label and grandtotalvalue to make decision 
    }
}
