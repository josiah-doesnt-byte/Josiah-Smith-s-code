
/**
 * Write a description of class CoinContainer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CoinContainer extends Container<Coin>
{
    private int value;
    private CoinContainer next;
    
    public CoinContainer()
    {
        this(1);
    }

    public CoinContainer(int value)
    {
        this.value = value;
        next = null;
    }

    public int getValue()
    {
        return this.value;
    }
    
    public int getTotalValue()
    {
        return getCount() * getValue();
    }
    
    public int getGrandTotalValue()
    {
        if(next == null)
        {
            return getTotalValue();
        }
        else
        {
            return getTotalValue() + next.getGrandTotalValue();
        }
    }

    @Override
    public void add(Coin coin)
    {
        if(coin.getValue() == this.value)
        {
            super.add(coin);
        }
        else
        {
            if(next != null)
            {
                next.add(coin);
            }
        }
    }
    
    public void append(CoinContainer container)
    {
        if(next == null)
        {
            next = container;
        }
        else
        {
            next.append(container);
        }
    }
    
    public static CoinContainer defaultContainer()
    {
        CoinContainer cc = new CoinContainer(100);
        cc.append(new CoinContainer(50));
        cc.append(new CoinContainer(25));
        cc.append(new CoinContainer(10));
        cc.append(new CoinContainer(5));
        cc.append(new CoinContainer(1));
        
        return cc;
    }
}
