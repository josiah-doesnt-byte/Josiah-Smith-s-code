
/**
 * Write a description of class ProductContainer here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ProductContainer extends Container<Product>
{
    Product product;
    
    public ProductContainer()
    {
        super();
    }
    
    @Override
    public void add(Product product)
    {
        if(getCount() == 0)
        {
            super.add(product);
        }
        else
        {
            Product sample = remove();
            if(product.equals(sample))
            {
                super.add(product);
            }
            super.add(sample);
        }
    }
    
    
    public static ProductContainer makeContainerWith(Product product, int quantity)
    {
        ProductContainer pc = new ProductContainer();
        for(int counter = 0; counter < quantity; counter++)
        {
            pc.add(new Product(product.getName(), product.getValue()));
        }
       
        return pc;
    }
}
