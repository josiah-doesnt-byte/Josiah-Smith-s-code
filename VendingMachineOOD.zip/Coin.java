
/**
 * Write a description of class Coin here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Coin
{
    // instance variables - replace the example below with your own
    private int value;

    /**
     * Constructor for objects of class Coin
     */
    public Coin()
    {
        this(1);
    }
    
    public Coin(int value)
    {
        this.value = value;
    }
    
    public int getValue()
    {
        return value;
    }
}
