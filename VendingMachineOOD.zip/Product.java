
/**
 * Write a description of class Product here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Product
{
    private int value;
    private String name;

    public Product()
    {
        this("No Name");
    }
    
    public Product(String name)
    {
        this(name, 1);
    }
    
    public Product(String name, int value)
    {
        this.name = name;
        this.value = value;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public int getValue()
    {
        return this.value;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        return ((Product)obj).getName() == getName() && ((Product)obj).getValue() == getValue();
    }
}
