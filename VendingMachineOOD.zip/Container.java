import java.util.List;
import java.util.ArrayList;

/**
 * Write a description of class Container here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Container<E>
{
    // instance variables - replace the example below with your own
    private List<E> contents;
    /**
     * Constructor for objects of class Container
     */
    public Container()
    {
        contents = new ArrayList<E>();
    }
    
    public void add(E item)
    {
        contents.add(item);
    }
    
    public E remove()
    {
        return contents.remove(0);
    }
    
    public int getCount()
    {
        return contents.size();
    }
}
